#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
int myNumbers[5] = {10, 20, 30, 40, 50};
for (int i = 0; i < sizeof(myNumbers) / sizeof(int); i++) {
  cout << myNumbers[i] << "\n";
}
}
