#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
  int x=10;
cout<<(10==19);
}