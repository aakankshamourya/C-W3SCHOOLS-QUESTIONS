#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
string letters[2][4] = {
  { "A", "B", "C", "D" },
  { "E", "F", "G", "H" }
};
cout<<letters[0][2];
}

