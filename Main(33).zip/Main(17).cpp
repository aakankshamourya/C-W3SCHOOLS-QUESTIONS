#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
int i = 0;
do {
  cout << i << "\n";
  i++;
}
while (i < 5);
}
