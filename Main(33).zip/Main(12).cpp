#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
int time = 20;
if (time < 18) {
  cout << "Good day.";
} else {
  cout << "Good evening.";
}
}