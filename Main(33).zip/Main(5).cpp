#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
bool isCodingFun = true;
bool isFishTasty = false;
cout << isCodingFun<<"\n";//puts 1 (true)
cout << isFishTasty;  // Outputs 0 (false)
}