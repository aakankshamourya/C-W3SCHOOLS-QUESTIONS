#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
int time = 22;
string result=(time<18)?"Good Day":"Good Evening";
cout<<result;
}