#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
string cars[4] = {"Volvo", "BMW", "Ford", "Mazda"};
cout << cars[0];
}
