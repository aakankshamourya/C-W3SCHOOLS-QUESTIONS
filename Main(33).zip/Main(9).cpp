#include <iostream>
#include<string>
#include<cmath>
using namespace std;

int main() 
{
int myAge = 25;
int votingAge = 18;

cout << (myAge >= votingAge);
}